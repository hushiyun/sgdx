const express = require('express');
const app = express();

app.listen(3000, function () {
    console.log('Example app listening on port 3000!');
});

//helmet
const helmet = require('helmet');
app.use(helmet());

//mongoose
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/test',{ useNewUrlParser: true });
const db = mongoose.connection;
db.once('open', function() {
    console.log('datebase is connected');
});

//template engines
app.set('view engine', 'ejs');

//Serving static files
app.use(express.static('public'));

//body-parser
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));

//cookie-parser
const cookieParser = require('cookie-parser');
app.use(cookieParser());


//routers
//index router
const indexRouter = require('./routers/index');
app.use('/',indexRouter.router);

//introduction router
const introductionRouter = require('./routers/introduction');
app.use('/introduction',introductionRouter.router);

//products router
const productsRouter = require('./routers/products');
app.use('/products',productsRouter.router);

//pictures router
const picturesRouter = require('./routers/pictures');
app.use('/pictures',picturesRouter.router);

//videos router
const videosRouter = require('./routers/videos');
app.use('/videos',videosRouter.router);

//contact router
const contactRouter = require('./routers/contact');
app.use('/contact',contactRouter.router);

